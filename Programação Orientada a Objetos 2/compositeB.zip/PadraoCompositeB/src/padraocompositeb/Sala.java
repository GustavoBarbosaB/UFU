/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padraocompositeb;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Gustavo
 */
public class Sala extends Labirinto{
    
    ArrayList<Labirinto> caminho = new ArrayList<>();
    int id;
    
    public Sala(int i)
    {
        this.id=i;
               
    }
    public void adicionarCaminho(Labirinto a)
    {
        this.caminho.add(a);
    }
    
    public int getID()
    {
        return this.id;
    }

    @Override
    public void goThis() {
        Random gerador = new Random();
        int j = gerador.nextInt(caminho.size());
        
        System.out.println("Você está na Sala"+this.getID());
        System.out.println("Selecione um caminho entre os "+caminho.size()+" existentes.");
        System.out.println("Caminho "+j+" escolhido.");
        caminho.get(j).goThis();//pega o caminho e continua
        
    }
    
}
