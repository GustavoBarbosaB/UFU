/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padraocompositeb;

/**
 *
 * @author Gustavo
 */
public abstract class Labirinto {
    
    public abstract void goThis();
    
    public void adicionarCaminho(Labirinto a){
        this.adicionarCaminho(a);
    }
    
}
