/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padraocompositeb;

import java.util.ArrayList;

/**
 *
 * @author Gustavo
 */
public class PadraoCompositeB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //criando as salas
        Labirinto inicio = new Sala(1);
        Labirinto sala2 = new Sala(2);
        Labirinto sala3 = new Sala(3);
        Labirinto sala4 = new Sala(4);
        Labirinto sala5 = new Sala(5);
                
        //Montando salas com abismos/saidas      
        inicio.adicionarCaminho(new Abismo());
        sala2.adicionarCaminho(new Abismo());
        sala3.adicionarCaminho(new Abismo());
        sala4.adicionarCaminho(new Saida());
        sala5.adicionarCaminho(new Abismo());
        
        //adicionando uma sala dentro da outra
        sala4.adicionarCaminho(sala5);
        sala2.adicionarCaminho(sala3);
        sala2.adicionarCaminho(sala4);
        inicio.adicionarCaminho(sala2);
        
        inicio.goThis();
        
        
        
      
    }
    
}
